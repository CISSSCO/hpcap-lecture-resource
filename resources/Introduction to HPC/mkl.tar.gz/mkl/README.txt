gcc -o matrix_multiply matrix_multiply.c -lmkl_rt -lpthread -lm -ldl -fopenmp

gcc: This is the GNU Compiler Collection.

-o matrix_multiply: Specifies the output file name. In this case, the compiled executable will be named matrix_multiply.

matrix_multiply.c: The source code file to be compiled.

-lmkl_rt: Links with the Intel Math Kernel Library Runtime. The -l flag is used to specify a library, and mkl_rt is the library name for the Intel MKL runtime.

-lpthread: Links with the POSIX threads library (libpthread). This library is necessary for multithreading support, and Intel MKL uses it for parallelism.

-lm: Links with the math library (libm). This library provides various mathematical functions.

-ldl: Links with the dynamic linking library (libdl). This library provides functions for dynamic loading of shared objects (libraries).

-fopenmp: Enables support for OpenMP (Open Multi-Processing). This flag is required when using OpenMP directives and functions in the code.


-lmkl_rt: Intel MKL Runtime library.
-lpthread: POSIX threads library.
-lm: Math library.
-ldl: Dynamic linking library.
-fopenmp: OpenMP support.


