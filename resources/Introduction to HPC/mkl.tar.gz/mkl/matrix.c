#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void matrix_multiply_without_mkl(int n, double *A, double *B, double *C) {
    int i, j, k;
    for (i = 0; i < n; i++) {
        for (j = 0; j < n; j++) {
            C[i * n + j] = 0.0;
            for (k = 0; k < n; k++) {
                C[i * n + j] += A[i * n + k] * B[k * n + j];
            }
        }
    }
}

void matrix_multiply_with_mkl(int n, double *A, double *B, double *C) {
    #include <mkl.h>
    cblas_dgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans, n, n, n, 1.0, A, n, B, n, 0.0, C, n);
}

int main() {
    int n = 1000;

    double *matrix_A = (double *)malloc(n * n * sizeof(double));
    double *matrix_B = (double *)malloc(n * n * sizeof(double));
    double *result_without_mkl = (double *)malloc(n * n * sizeof(double));
    double *result_with_mkl = (double *)malloc(n * n * sizeof(double));

    srand(time(NULL));
    for (int i = 0; i < n * n; i++) {
        matrix_A[i] = (double)rand() / RAND_MAX;
        matrix_B[i] = (double)rand() / RAND_MAX;
    }

    clock_t start_time = clock();
    matrix_multiply_without_mkl(n, matrix_A, matrix_B, result_without_mkl);
    clock_t end_time = clock();
    printf("Time without MKL: %.4f seconds\n", ((double)(end_time - start_time)) / CLOCKS_PER_SEC);

    start_time = clock();
    matrix_multiply_with_mkl(n, matrix_A, matrix_B, result_with_mkl);
    end_time = clock();
    printf("Time with MKL: %.4f seconds\n", ((double)(end_time - start_time)) / CLOCKS_PER_SEC);

    for (int i = 0; i < n * n; i++) {
        if (result_without_mkl[i] != result_with_mkl[i]) {
            printf("Results differ at index %d\n", i);
            break;
        }
    }
    printf("Results are the same.\n");

    free(matrix_A);
    free(matrix_B);
    free(result_without_mkl);
    free(result_with_mkl);

    return 0;
}

