#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void matrix_multiply_without_blas(int n, double *A, double *B, double *C) {
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            C[i * n + j] = 0.0;
            for (int k = 0; k < n; k++) {
                C[i * n + j] += A[i * n + k] * B[k * n + j];
            }
        }
    }
}

void matrix_multiply_with_openblas(int n, double *A, double *B, double *C) {
    #include <cblas.h>
    cblas_dgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans, n, n, n, 1.0, A, n, B, n, 0.0, C, n);
}

int main() {
    int n = 1000;

    double *matrix_A = (double *)malloc(n * n * sizeof(double));
    double *matrix_B = (double *)malloc(n * n * sizeof(double));
    double *result_without_blas = (double *)malloc(n * n * sizeof(double));
    double *result_with_openblas = (double *)malloc(n * n * sizeof(double));

    srand(time(NULL));
    for (int i = 0; i < n * n; i++) {
        matrix_A[i] = (double)rand() / RAND_MAX;
        matrix_B[i] = (double)rand() / RAND_MAX;
    }

    clock_t start_time = clock();
    matrix_multiply_without_blas(n, matrix_A, matrix_B, result_without_blas);
    clock_t end_time = clock();
    printf("Time without OpenBLAS: %.4f seconds\n", ((double)(end_time - start_time)) / CLOCKS_PER_SEC);

    start_time = clock();
    matrix_multiply_with_openblas(n, matrix_A, matrix_B, result_with_openblas);
    end_time = clock();
    printf("Time with OpenBLAS: %.4f seconds\n", ((double)(end_time - start_time)) / CLOCKS_PER_SEC);

    for (int i = 0; i < n * n; i++) {
        if (result_without_blas[i] != result_with_openblas[i]) {
            printf("Results differ at index %d\n", i);
            break;
        }
    }
    printf("Results are the same.\n");

    free(matrix_A);
    free(matrix_B);
    free(result_without_blas);
    free(result_with_openblas);

    return 0;
}

