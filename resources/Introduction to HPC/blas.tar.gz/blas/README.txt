gcc -o matrix_multiply matrix.c -L/home/apps/spack/opt/spack/linux-centos7-skylake_avx512/gcc-8.3.0/openblas-0.3.18-t435bnt4h2vkl5xabvymxtmouspvo76l/lib -lopenblas -lpthread -lm -ldl -fopenmp

gcc: This is the GNU Compiler Collection.

-o matrix_multiply: Specifies the output file name. In this case, the compiled executable will be named matrix_multiply.

matrix_multiply.c: The source code file to be compiled.

-lopenblas: Links with the OpenBLAS library. The -l flag is used to specify a library, and openblas is the library name. This flag tells the linker to include the OpenBLAS library during the linking process.

-lpthread: Links with the POSIX threads library (libpthread). This library is necessary for multithreading support, and OpenBLAS uses it for parallelism.

-lm: Links with the math library (libm). This library provides various mathematical functions.

-fopenmp: Enables support for OpenMP (Open Multi-Processing). This flag is required when using OpenMP directives and functions in the code. OpenBLAS may use OpenMP for parallelism.

-lopenblas: OpenBLAS library.
-lpthread: POSIX threads library.
-lm: Math library.
-fopenmp: OpenMP support.
